var require = meteorInstall({"lib":{"storage.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// lib/storage.js                                                                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Images = new FS.Collection("Images", {                                                                       // 1
    stores: [new FS.Store.GridFS("thumbs", {                                                                 // 2
        transformWrite: function (fileObj, readStream, writeStream) {                                        // 4
            // Transform the image into a 10x10px thumbnail                                                  // 5
            gm(readStream, fileObj.name()).resize('150', '240').stream().pipe(writeStream);                  // 6
        }                                                                                                    // 7
    }), new FS.Store.GridFS("container")] // filter: {                                                       // 3
    //     maxSize: 5242880,//bytes -> 5MB                                                                   // 12
    //     allow: {                                                                                          // 13
    //         contentType: ['image/*']                                                                      // 14
    //     }                                                                                                 // 15
    // }                                                                                                     // 16
                                                                                                             //
});                                                                                                          // 1
Codigos = new Mongo.Collection("Codigos");                                                                   // 22
Counters = new Mongo.Collection('counters');                                                                 // 23
TVs = new Mongo.Collection("TVs");                                                                           // 24
TVsImages = new Mongo.Collection("TVsImages");                                                               // 25
Meteor.users.allow({                                                                                         // 26
    insert: function () {                                                                                    // 27
        return false;                                                                                        // 28
    },                                                                                                       // 29
    remove: function () {                                                                                    // 30
        return false;                                                                                        // 31
    },                                                                                                       // 32
    update: function () {                                                                                    // 33
        return false;                                                                                        // 34
    }                                                                                                        // 35
});                                                                                                          // 26
Images.allow({                                                                                               // 37
    insert: function () {                                                                                    // 38
        return true;                                                                                         // 39
    },                                                                                                       // 40
    remove: function () {                                                                                    // 41
        return true;                                                                                         // 42
    },                                                                                                       // 43
    update: function () {                                                                                    // 44
        return true;                                                                                         // 45
    },                                                                                                       // 46
    download: function () {                                                                                  // 47
        return true;                                                                                         // 48
    }                                                                                                        // 49
});                                                                                                          // 37
Counters.allow({                                                                                             // 52
    insert: function () {                                                                                    // 53
        return true;                                                                                         // 54
    },                                                                                                       // 55
    remove: function () {                                                                                    // 56
        return true;                                                                                         // 57
    },                                                                                                       // 58
    update: function () {                                                                                    // 59
        return true;                                                                                         // 60
    }                                                                                                        // 61
});                                                                                                          // 52
Codigos.allow({                                                                                              // 63
    insert: function () {                                                                                    // 64
        return false;                                                                                        // 65
    },                                                                                                       // 66
    remove: function () {                                                                                    // 67
        return false;                                                                                        // 68
    },                                                                                                       // 69
    update: function () {                                                                                    // 70
        return false;                                                                                        // 71
    }                                                                                                        // 72
});                                                                                                          // 63
TVs.allow({                                                                                                  // 74
    insert: function () {                                                                                    // 75
        return false;                                                                                        // 76
    },                                                                                                       // 77
    remove: function () {                                                                                    // 78
        return false;                                                                                        // 79
    },                                                                                                       // 80
    update: function () {                                                                                    // 81
        return false;                                                                                        // 82
    }                                                                                                        // 83
});                                                                                                          // 74
TVsImages.allow({                                                                                            // 85
    insert: function () {                                                                                    // 86
        return false;                                                                                        // 87
    },                                                                                                       // 88
    remove: function () {                                                                                    // 89
        return false;                                                                                        // 90
    },                                                                                                       // 91
    update: function () {                                                                                    // 92
        return false;                                                                                        // 93
    }                                                                                                        // 94
});                                                                                                          // 85
Meteor.users.deny({                                                                                          // 96
    insert: function () {                                                                                    // 97
        return true;                                                                                         // 98
    },                                                                                                       // 99
    remove: function () {                                                                                    // 100
        return true;                                                                                         // 101
    },                                                                                                       // 102
    update: function () {                                                                                    // 103
        return true;                                                                                         // 104
    }                                                                                                        // 105
});                                                                                                          // 96
Images.deny({                                                                                                // 107
    insert: function () {                                                                                    // 108
        return false;                                                                                        // 109
    },                                                                                                       // 110
    remove: function () {                                                                                    // 111
        return false;                                                                                        // 112
    },                                                                                                       // 113
    update: function () {                                                                                    // 114
        return false;                                                                                        // 115
    },                                                                                                       // 116
    download: function () {                                                                                  // 117
        return false;                                                                                        // 118
    }                                                                                                        // 119
});                                                                                                          // 107
Counters.deny({                                                                                              // 122
    insert: function () {                                                                                    // 123
        return false;                                                                                        // 124
    },                                                                                                       // 125
    remove: function () {                                                                                    // 126
        return false;                                                                                        // 127
    },                                                                                                       // 128
    update: function () {                                                                                    // 129
        return false;                                                                                        // 130
    }                                                                                                        // 131
});                                                                                                          // 122
Codigos.deny({                                                                                               // 133
    insert: function () {                                                                                    // 134
        return true;                                                                                         // 135
    },                                                                                                       // 136
    remove: function () {                                                                                    // 137
        return true;                                                                                         // 138
    },                                                                                                       // 139
    update: function () {                                                                                    // 140
        return true;                                                                                         // 141
    }                                                                                                        // 142
});                                                                                                          // 133
TVs.deny({                                                                                                   // 144
    insert: function () {                                                                                    // 145
        return true;                                                                                         // 146
    },                                                                                                       // 147
    remove: function () {                                                                                    // 148
        return true;                                                                                         // 149
    },                                                                                                       // 150
    update: function () {                                                                                    // 151
        return true;                                                                                         // 152
    }                                                                                                        // 153
});                                                                                                          // 144
TVsImages.deny({                                                                                             // 155
    insert: function () {                                                                                    // 156
        return true;                                                                                         // 157
    },                                                                                                       // 158
    remove: function () {                                                                                    // 159
        return true;                                                                                         // 160
    },                                                                                                       // 161
    update: function () {                                                                                    // 162
        return true;                                                                                         // 163
    }                                                                                                        // 164
});                                                                                                          // 155
Meteor.startup(function () {                                                                                 // 166
    Meteor.methods({                                                                                         // 167
        incrementarContador: function () {                                                                   // 168
            // setCounter(Counters, 'cantMedia', 0)                                                          // 169
            return incrementCounter(Counters, 'cantMedia', 1);                                               // 170
        },                                                                                                   // 171
        updateOrder: function (Codigo, order) {                                                              // 172
            // setCounter(Counters, 'cantMedia', 0)                                                          // 173
            Codigos.update({                                                                                 // 174
                Codigo: Codigo                                                                               // 174
            }, {                                                                                             // 174
                $set: {                                                                                      // 174
                    Order: order                                                                             // 174
                }                                                                                            // 174
            });                                                                                              // 174
        },                                                                                                   // 175
        updateTVOrder: function (tvname, imagecode, order) {                                                 // 176
            // setCounter(Counters, 'cantMedia', 0)                                                          // 177
            TVsImages.update({                                                                               // 178
                tvname: tvname,                                                                              // 178
                imagecode: imagecode                                                                         // 178
            }, {                                                                                             // 178
                $set: {                                                                                      // 178
                    order: order                                                                             // 178
                }                                                                                            // 178
            });                                                                                              // 178
        }                                                                                                    // 179
    });                                                                                                      // 167
});                                                                                                          // 181
                                                                                                             //
if (Meteor.isServer) {                                                                                       // 183
    Meteor.publish("files.all", function () {                                                                // 184
        return Images.find();                                                                                // 185
    });                                                                                                      // 186
    Meteor.publish("codigos", function () {                                                                  // 187
        return Codigos.find();                                                                               // 188
    });                                                                                                      // 189
    Meteor.publish("counters", function () {                                                                 // 190
        return Counters.find();                                                                              // 191
    });                                                                                                      // 192
    Meteor.publish("TVs", function () {                                                                      // 193
        return TVs.find();                                                                                   // 194
    });                                                                                                      // 195
    Meteor.publish('TVsImages.view', function (tvname) {                                                     // 196
        return TVsImages.find({                                                                              // 197
            tvname: tvname                                                                                   // 197
        });                                                                                                  // 197
    });                                                                                                      // 198
    Meteor.publish('users', function () {                                                                    // 199
        return Meteor.users.find({});                                                                        // 200
    });                                                                                                      // 201
}                                                                                                            // 202
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"api":{"Ads.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Ads.js                                                                                        //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Ad = new Mongo.Collection('ads');                                                                            // 1
var schema = {};                                                                                             // 2
schema.Ad = new SimpleSchema({                                                                               // 3
    timeOut: {                                                                                               // 4
        type: Number                                                                                         // 5
    }                                                                                                        // 4
});                                                                                                          // 3
Ad.attachSchema(schema.Ad);                                                                                  // 8
                                                                                                             //
if (Meteor.isServer) {                                                                                       // 10
    Meteor.publish("ads", function () {                                                                      // 11
        return Ad.find({});                                                                                  // 12
    });                                                                                                      // 13
}                                                                                                            // 14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"functions.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/functions.js                                                                                       //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Meteor.startup(function () {                                                                                 // 1
	UploadServer.init({                                                                                         // 2
		tmpDir: process.env.PWD + '/.uploads/tmp',                                                                 // 3
		uploadDir: process.env.PWD + '/.uploads/',                                                                 // 4
		overwrite: true,                                                                                           // 5
		checkCreateDirectories: true,                                                                              // 6
		cacheTime: 100,                                                                                            // 7
		mimeTypes: {                                                                                               // 8
			"jpeg": "image/jpeg",                                                                                     // 9
			"jpg": "image/jpeg",                                                                                      // 10
			"png": "image/png",                                                                                       // 11
			"gif": "image/gif",                                                                                       // 12
			"mp4": "video/mp4" // ,finished:function(fileInfo){                                                       // 13
			// 	function fixedEncodeURIComponent (str) {                                                              // 16
			// 	  return encodeURIComponent(str).replace(/[!'()*]/g, function(c) {                                    // 17
			// 	    return '%' + c.charCodeAt(0).toString(16);                                                        // 18
			// 	  });                                                                                                 // 19
			// 	}                                                                                                     // 20
			// 	var options = Options.findOne({"_id":"01"});                                                          // 21
			// 	Options.update({"_id": "01"}, {$push: {"ads.pictureUrls": options.general.adminUrl+"/upload/"+fixedEncodeURIComponent(fileInfo.name)}});
			// 	console.log('File uploaded: '+fixedEncodeURIComponent(fileInfo.name));                                // 23
			// }                                                                                                      // 24
                                                                                                             //
		},                                                                                                         // 8
		getDirectory: function (fileInfo, formData) {                                                              // 25
			if (formData && formData.directoryName != null) {                                                         // 26
				return formData.directoryName;                                                                           // 27
			}                                                                                                         // 28
                                                                                                             //
			return "";                                                                                                // 29
		},                                                                                                         // 30
		finished: function (fileInfo, formData) {                                                                  // 31
			function fixedEncodeURIComponent(str) {                                                                   // 32
				return encodeURIComponent(str).replace(/[!'()*]/g, function (c) {                                        // 33
					return '%' + c.charCodeAt(0).toString(16);                                                              // 34
				});                                                                                                      // 35
			}                                                                                                         // 36
                                                                                                             //
			console.log(formData.type);                                                                               // 37
                                                                                                             //
			if (formData.type == 'ad') {                                                                              // 38
				if (fileInfo.type == 'image/jpeg' || fileInfo.type == 'image/png') {                                     // 39
					console.log("uploaded file it's an ad");                                                                // 40
					var options = Options.findOne({                                                                         // 41
						"_id": "01"                                                                                            // 41
					});                                                                                                     // 41
					Options.update({                                                                                        // 42
						"_id": "01"                                                                                            // 42
					}, {                                                                                                    // 42
						$push: {                                                                                               // 42
							"ads.pictureUrls": options.general.adminUrl + "/upload/" + fixedEncodeURIComponent(fileInfo.name)     // 42
						}                                                                                                      // 42
					});                                                                                                     // 42
					console.log('Ad uploaded: ' + fixedEncodeURIComponent(fileInfo.name));                                  // 43
				}                                                                                                        // 44
			}                                                                                                         // 45
                                                                                                             //
			if (formData.type == 'videoTop') {                                                                        // 46
				console.log("uploaded file it's a video");                                                               // 47
				var options = Options.findOne({                                                                          // 48
					"_id": "01"                                                                                             // 48
				});                                                                                                      // 48
				Options.update({                                                                                         // 49
					"_id": "01"                                                                                             // 49
				}, {                                                                                                     // 49
					$set: {                                                                                                 // 49
						"Videos.top": options.general.adminUrl + "/stream/" + fixedEncodeURIComponent(fileInfo.name)           // 49
					}                                                                                                       // 49
				});                                                                                                      // 49
				console.log('Top video uploaded: ' + fixedEncodeURIComponent(fileInfo.name));                            // 50
			}                                                                                                         // 51
                                                                                                             //
			if (formData.type == 'videoBottom') {                                                                     // 52
				console.log("uploaded file it's a video");                                                               // 53
				var options = Options.findOne({                                                                          // 54
					"_id": "01"                                                                                             // 54
				});                                                                                                      // 54
				Options.update({                                                                                         // 55
					"_id": "01"                                                                                             // 55
				}, {                                                                                                     // 55
					$set: {                                                                                                 // 55
						"Videos.bottom": options.general.adminUrl + "/stream/" + fixedEncodeURIComponent(fileInfo.name)        // 55
					}                                                                                                       // 55
				});                                                                                                      // 55
				console.log('Bottom video uploaded: ' + fixedEncodeURIComponent(fileInfo.name));                         // 56
			}                                                                                                         // 57
		}                                                                                                          // 58
	});                                                                                                         // 2
});                                                                                                          // 60
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/main.js                                                                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var Meteor = void 0;                                                                                         // 1
module.watch(require("meteor/meteor"), {                                                                     // 1
	Meteor: function (v) {                                                                                      // 1
		Meteor = v;                                                                                                // 1
	}                                                                                                           // 1
}, 0);                                                                                                       // 1
module.watch(require("../imports/api/Ads"));                                                                 // 1
Accounts.config({                                                                                            // 6
	forbidClientAccountCreation: true                                                                           // 7
});                                                                                                          // 6
                                                                                                             //
if (!Meteor.isProduction) {                                                                                  // 11
	var users = [{                                                                                              // 12
		email: 'admin@admin.com',                                                                                  // 13
		password: 'password',                                                                                      // 14
		profile: {                                                                                                 // 15
			fullname: 'Carl Winslow',                                                                                 // 16
			role: 'administrador'                                                                                     // 17
		}                                                                                                          // 15
	}];                                                                                                         // 12
	users.forEach(function (_ref) {                                                                             // 21
		var email = _ref.email,                                                                                    // 21
		    password = _ref.password,                                                                              // 21
		    profile = _ref.profile,                                                                                // 21
		    roles = _ref.roles;                                                                                    // 21
		var userExists = Meteor.users.findOne({                                                                    // 22
			'emails.address': email                                                                                   // 22
		});                                                                                                        // 22
                                                                                                             //
		if (!userExists) {                                                                                         // 24
			var userId = Accounts.createUser({                                                                        // 25
				email: email,                                                                                            // 25
				password: password,                                                                                      // 25
				profile: profile                                                                                         // 25
			});                                                                                                       // 25
		}                                                                                                          // 26
	});                                                                                                         // 27
}                                                                                                            // 28
                                                                                                             //
Meteor.startup(function () {                                                                                 // 31
	Meteor.methods({                                                                                            // 32
		insertCodigo: function (Codigo, Time, Order, fileFormat) {                                                 // 33
			if (Meteor.userId) {                                                                                      // 34
				Codigos.insert({                                                                                         // 35
					Codigo: Codigo,                                                                                         // 35
					Time: Time,                                                                                             // 35
					Order: Order,                                                                                           // 35
					fileFormat: fileFormat                                                                                  // 35
				});                                                                                                      // 35
			} else {                                                                                                  // 36
				throw new Meteor.Error("No-autorizado");                                                                 // 37
			}                                                                                                         // 38
		},                                                                                                         // 39
		insertTV: function (tvname) {                                                                              // 40
			if (Meteor.userId) {                                                                                      // 41
				if (TVs.find({                                                                                           // 42
					Name: tvname                                                                                            // 42
				}).fetch().length > 0) {                                                                                 // 42
					throw new Meteor.Error("Elige otro nombre, Televisor ya existe.");                                      // 43
				} else {                                                                                                 // 44
					TVs.insert({                                                                                            // 45
						Name: tvname                                                                                           // 45
					});                                                                                                     // 45
				}                                                                                                        // 46
			} else {                                                                                                  // 48
				throw new Meteor.Error("No-autorizado");                                                                 // 49
			}                                                                                                         // 50
		},                                                                                                         // 51
		addTVImage: function (tvname, imagecode, time, fileFormat) {                                               // 52
			if (Meteor.userId) {                                                                                      // 53
				if (TVsImages.find({                                                                                     // 54
					tvname: tvname,                                                                                         // 54
					imagecode: imagecode                                                                                    // 54
				}).fetch().length > 0) {                                                                                 // 54
					throw new Meteor.Error("Imagen ya está agregada.");                                                     // 55
				} else {                                                                                                 // 56
					TVsImages.insert({                                                                                      // 57
						tvname: tvname,                                                                                        // 57
						imagecode: imagecode,                                                                                  // 57
						time: time,                                                                                            // 57
						order: 1,                                                                                              // 57
						fileFormat: fileFormat                                                                                 // 57
					});                                                                                                     // 57
				}                                                                                                        // 58
			} else {                                                                                                  // 60
				throw new Meteor.Error("No-autorizado");                                                                 // 61
			}                                                                                                         // 62
		},                                                                                                         // 63
		uploadFile: function (fileInfo) {/*Por seguridad podriamos implementar la subida                           // 64
                                     del archivo en el server, es opcional                                   //
                                   */},                                                                      //
		deleteTV: function (Name) {                                                                                // 69
			if (Meteor.userId) {                                                                                      // 70
				TVs.remove({                                                                                             // 71
					Name: Name                                                                                              // 71
				});                                                                                                      // 71
				TVsImages.remove({                                                                                       // 72
					tvname: Name                                                                                            // 72
				}, {                                                                                                     // 72
					multi: true                                                                                             // 72
				});                                                                                                      // 72
				return "ok";                                                                                             // 73
			} else {                                                                                                  // 74
				throw new Meteor.Error("No-autorizado");                                                                 // 75
			}                                                                                                         // 76
		},                                                                                                         // 77
		editTV: function (oldName, newName) {                                                                      // 78
			if (Meteor.userId) {                                                                                      // 79
				TVsImages.update({                                                                                       // 80
					tvname: oldName                                                                                         // 80
				}, {                                                                                                     // 80
					$set: {                                                                                                 // 80
						tvname: newName                                                                                        // 80
					}                                                                                                       // 80
				}, {                                                                                                     // 80
					multi: true                                                                                             // 80
				});                                                                                                      // 80
				TVs.update({                                                                                             // 81
					Name: oldName                                                                                           // 81
				}, {                                                                                                     // 81
					$set: {                                                                                                 // 81
						Name: newName                                                                                          // 81
					}                                                                                                       // 81
				});                                                                                                      // 81
				return "Ok";                                                                                             // 82
			} else {                                                                                                  // 83
				throw new Meteor.Error("No-autorizado");                                                                 // 84
			}                                                                                                         // 85
		},                                                                                                         // 86
		deleteImage: function (imageRef) {                                                                         // 87
			if (Meteor.userId) {                                                                                      // 88
				Images.remove({                                                                                          // 89
					_id: imageRef                                                                                           // 89
				});                                                                                                      // 89
				Codigos.remove({                                                                                         // 90
					Codigo: imageRef                                                                                        // 90
				});                                                                                                      // 90
				TVsImages.remove({                                                                                       // 91
					imagecode: imageRef                                                                                     // 91
				}, {                                                                                                     // 91
					multi: true                                                                                             // 91
				});                                                                                                      // 91
				return "ok";                                                                                             // 92
			} else {                                                                                                  // 93
				throw new Meteor.Error("No-autorizado");                                                                 // 94
			}                                                                                                         // 95
		},                                                                                                         // 96
		deleteImageTV: function (imageRef, tvname) {                                                               // 97
			if (Meteor.userId) {                                                                                      // 98
				TVsImages.remove({                                                                                       // 99
					imagecode: imageRef,                                                                                    // 99
					tvname: tvname                                                                                          // 99
				});                                                                                                      // 99
				return "ok";                                                                                             // 100
			} else {                                                                                                  // 101
				throw new Meteor.Error("No-autorizado");                                                                 // 102
			}                                                                                                         // 103
		},                                                                                                         // 104
		timeoutAd: function (timeout, id) {                                                                        // 105
			if (Meteor.userId) {                                                                                      // 106
				Ad.update({                                                                                              // 107
					_id: id                                                                                                 // 107
				}, {                                                                                                     // 107
					$set: {                                                                                                 // 107
						timeOut: timeout                                                                                       // 107
					}                                                                                                       // 107
				});                                                                                                      // 107
				Codigos.update({}, {                                                                                     // 108
					$set: {                                                                                                 // 108
						Time: timeout                                                                                          // 108
					}                                                                                                       // 108
				}, {                                                                                                     // 108
					multi: true                                                                                             // 108
				});                                                                                                      // 108
				return "Ok";                                                                                             // 109
			} else {                                                                                                  // 110
				throw new Meteor.Error("No-autorizado");                                                                 // 111
			}                                                                                                         // 112
		},                                                                                                         // 113
		timeoutbyAd: function (imageRef, timeout) {                                                                // 114
			if (Meteor.userId) {                                                                                      // 115
				Codigos.update({                                                                                         // 116
					Codigo: imageRef                                                                                        // 116
				}, {                                                                                                     // 116
					$set: {                                                                                                 // 116
						Time: timeout                                                                                          // 116
					}                                                                                                       // 116
				});                                                                                                      // 116
				return "Ok";                                                                                             // 117
			} else {                                                                                                  // 118
				throw new Meteor.Error("No-autorizado");                                                                 // 119
			}                                                                                                         // 120
		},                                                                                                         // 121
		timeoutbyAdbyTV: function (imageRef, tvname, timeout) {                                                    // 122
			if (Meteor.userId) {                                                                                      // 123
				TVsImages.update({                                                                                       // 124
					tvname: tvname,                                                                                         // 124
					imagecode: imageRef                                                                                     // 124
				}, {                                                                                                     // 124
					$set: {                                                                                                 // 124
						time: timeout                                                                                          // 124
					}                                                                                                       // 124
				});                                                                                                      // 124
				return "Ok";                                                                                             // 125
			} else {                                                                                                  // 126
				throw new Meteor.Error("No-autorizado");                                                                 // 127
			}                                                                                                         // 128
		},                                                                                                         // 129
		crearUsuario: function (user) {                                                                            // 130
			if (Meteor.userId) {                                                                                      // 131
				return Accounts.createUser({                                                                             // 132
					username: user.username,                                                                                // 133
					password: user.password,                                                                                // 134
					profile: {                                                                                              // 135
						fullname: user.fullname,                                                                               // 136
						role: 'administrador'                                                                                  // 137
					}                                                                                                       // 135
				});                                                                                                      // 132
			} else {                                                                                                  // 140
				throw new Meteor.Error("No-autorizado");                                                                 // 141
			}                                                                                                         // 142
		},                                                                                                         // 144
		borrarUsuario: function (_id) {                                                                            // 145
			if (Meteor.userId) {                                                                                      // 146
				return Meteor.users.remove(_id);                                                                         // 147
			} else {                                                                                                  // 148
				throw new Meteor.Error("No-autorizado");                                                                 // 149
			}                                                                                                         // 150
		}                                                                                                          // 152
	});                                                                                                         // 32
});                                                                                                          // 154
                                                                                                             //
var fs = Npm.require('fs');                                                                                  // 156
                                                                                                             //
var url = Npm.require("url");                                                                                // 157
                                                                                                             //
var events = Npm.require("events");                                                                          // 158
                                                                                                             //
var handler = new events.EventEmitter();                                                                     // 159
var mimeTypes = {                                                                                            // 160
	".swf": "application/x-shockwave-flash",                                                                    // 161
	".flv": "video/x-flv",                                                                                      // 162
	".f4v": "video/mp4",                                                                                        // 163
	".f4p": "video/mp4",                                                                                        // 164
	".mp4": "video/mp4",                                                                                        // 165
	".asf": "video/x-ms-asf",                                                                                   // 166
	".asr": "video/x-ms-asf",                                                                                   // 167
	".asx": "video/x-ms-asf",                                                                                   // 168
	".avi": "video/x-msvideo",                                                                                  // 169
	".mpa": "video/mpeg",                                                                                       // 170
	".mpe": "video/mpeg",                                                                                       // 171
	".mpeg": "video/mpeg",                                                                                      // 172
	".mpg": "video/mpeg",                                                                                       // 173
	".mpv2": "video/mpeg",                                                                                      // 174
	".mov": "video/quicktime",                                                                                  // 175
	".movie": "video/x-sgi-movie",                                                                              // 176
	".mp2": "video/mpeg",                                                                                       // 177
	".qt": "video/quicktime",                                                                                   // 178
	".mp3": "audio/mpeg",                                                                                       // 179
	".wav": "audio/x-wav",                                                                                      // 180
	".aif": "audio/x-aiff",                                                                                     // 181
	".aifc": "audio/x-aiff",                                                                                    // 182
	".aiff": "audio/x-aiff",                                                                                    // 183
	".jpe": "image/jpeg",                                                                                       // 184
	".jpeg": "image/jpeg",                                                                                      // 185
	".jpg": "image/jpeg",                                                                                       // 186
	".png": "image/png",                                                                                        // 187
	".svg": "image/svg+xml",                                                                                    // 188
	".tif": "image/tiff",                                                                                       // 189
	".tiff": "image/tiff",                                                                                      // 190
	".gif": "image/gif",                                                                                        // 191
	".txt": "text/plain",                                                                                       // 192
	".xml": "text/xml",                                                                                         // 193
	".css": "text/css",                                                                                         // 194
	".htm": "text/html",                                                                                        // 195
	".html": "text/html",                                                                                       // 196
	".pdf": "application/pdf",                                                                                  // 197
	".doc": "application/msword",                                                                               // 198
	".vcf": "text/x-vcard",                                                                                     // 199
	".vrml": "x-world/x-vrml",                                                                                  // 200
	".zip": "application/zip",                                                                                  // 201
	".webm": "video/webm",                                                                                      // 202
	".m3u8": "application/x-mpegurl",                                                                           // 203
	".ts": "video/mp2t",                                                                                        // 204
	".ogg": "video/ogg"                                                                                         // 205
};                                                                                                           // 160
var settings = {                                                                                             // 207
	"mode": "development",                                                                                      // 208
	"forceDownload": false,                                                                                     // 209
	"server": "beanStreamer",                                                                                   // 210
	"maxAge": "3600"                                                                                            // 211
};                                                                                                           // 207
                                                                                                             //
var isNumber = function (n) {                                                                                // 213
	return !isNaN(parseFloat(n)) && isFinite(n);                                                                // 214
};                                                                                                           // 215
                                                                                                             //
WebApp.connectHandlers.use(function (req, res, next) {                                                       // 216
	var re = /^\/stream\/(.*)$/.exec(req.url);                                                                  // 217
                                                                                                             //
	if (re !== null) {                                                                                          // 218
		// Only handle URLs that start with /uploads_url_prefix/*                                                  // 218
		var filePath = process.env.PWD + '/.uploads/video/' + re[1];                                               // 219
		var stat;                                                                                                  // 220
		var ext;                                                                                                   // 221
		var info = {};                                                                                             // 222
		var range = typeof req.headers.range === "string" ? req.headers.range : undefined;                         // 223
		var reqUrl = url.parse(req.url, true);                                                                     // 224
		console.log("range: " + req.headers.range);                                                                // 225
		ext = filePath.match(/.*(\..+?)$/);                                                                        // 227
		info.mime = mimeTypes[ext[1].toLowerCase()];                                                               // 228
		console.log("extension: " + info.mime);                                                                    // 229
                                                                                                             //
		try {                                                                                                      // 231
			data = fs.readFileSync(filePath);                                                                         // 232
		} catch (e) {                                                                                              // 233
			if (e.code === 'ENOENT') {                                                                                // 234
				handler.emit("notFound", res, e);                                                                        // 235
				return false;                                                                                            // 236
			} else {                                                                                                  // 237
				throw e;                                                                                                 // 238
			}                                                                                                         // 239
		}                                                                                                          // 240
                                                                                                             //
		info.path = filePath;                                                                                      // 242
		info.file = info.path.match(/(.*[\/|\\])?(.+?)$/)[2]; // var data = fs.readFileSync(filePath);             // 243
                                                                                                             //
		stat = fs.statSync(info.path); // console.log(stat);                                                       // 246
                                                                                                             //
		info.start = 0;                                                                                            // 249
		info.end = stat.size - 1;                                                                                  // 250
		info.size = stat.size;                                                                                     // 251
		info.modified = stat.mtime;                                                                                // 252
		info.rangeRequest = false;                                                                                 // 253
                                                                                                             //
		if (range !== undefined && (range = range.match(/bytes=(.+)-(.+)?/)) !== null) {                           // 255
			// Check range contains numbers and they fit in the file.                                                 // 256
			// Make sure info.start & info.end are numbers (not strings) or stream.pipe errors out if start > 0.      // 257
			info.start = isNumber(range[1]) && range[1] >= 0 && range[1] < info.end ? range[1] - 0 : info.start;      // 258
			info.end = isNumber(range[2]) && range[2] > info.start && range[2] <= info.end ? range[2] - 0 : info.end;
			info.rangeRequest = true;                                                                                 // 260
		} else if (reqUrl.query.start || reqUrl.query.end) {                                                       // 261
			// This is a range request, but doesn't get range headers. So there.                                      // 262
			info.start = isNumber(reqUrl.query.start) && reqUrl.query.start >= 0 && reqUrl.query.start < info.end ? reqUrl.query.start - 0 : info.start;
			info.end = isNumber(reqUrl.query.end) && reqUrl.query.end > info.start && reqUrl.query.end <= info.end ? reqUrl.query.end - 0 : info.end;
		}                                                                                                          // 265
                                                                                                             //
		info.length = info.end - info.start + 1;                                                                   // 267
		console.log("length: " + info.length);                                                                     // 268
		console.log("rangeRequest?: " + info.rangeRequest);                                                        // 269
		console.log("serving file: " + filePath);                                                                  // 270
		downloadHeader(res, info);                                                                                 // 272
		stream = fs.createReadStream(info.path, {                                                                  // 274
			flags: "r",                                                                                               // 274
			start: info.start,                                                                                        // 274
			end: info.end                                                                                             // 274
		});                                                                                                        // 274
		stream.pipe(res);                                                                                          // 275
		return true;                                                                                               // 276
	} else {                                                                                                    // 278
		next();                                                                                                    // 279
	}                                                                                                           // 280
                                                                                                             //
	;                                                                                                           // 280
});                                                                                                          // 281
                                                                                                             //
var downloadHeader = function (res, info) {                                                                  // 283
	var code = 200;                                                                                             // 284
	var header;                                                                                                 // 285
	header = {                                                                                                  // 287
		"Cache-Control": "public; max-age=" + settings.maxAge,                                                     // 288
		Connection: "keep-alive",                                                                                  // 289
		"Content-Type": info.mime,                                                                                 // 290
		"Content-Disposition": "inline; filename=" + info.file + ";",                                              // 291
		"Accept-Ranges": "bytes"                                                                                   // 292
	};                                                                                                          // 287
                                                                                                             //
	if (info.rangeRequest) {                                                                                    // 295
		// Partial http response                                                                                   // 296
		code = 206;                                                                                                // 297
		header.Status = "206 Partial Content";                                                                     // 298
		header["Content-Range"] = "bytes " + info.start + "-" + info.end + "/" + info.size;                        // 299
	}                                                                                                           // 300
                                                                                                             //
	header.Pragma = "public";                                                                                   // 302
	header["Last-Modified"] = info.modified.toUTCString();                                                      // 303
	header["Content-Transfer-Encoding"] = "binary";                                                             // 304
	header["Content-Length"] = info.length;                                                                     // 305
                                                                                                             //
	if (settings.cors) {                                                                                        // 306
		header["Access-Control-Allow-Origin"] = "*";                                                               // 307
		header["Access-Control-Allow-Headers"] = "Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept";
	}                                                                                                           // 309
                                                                                                             //
	header.Server = settings.server;                                                                            // 310
	header.Server = settings.server;                                                                            // 311
	res.writeHead(code, header);                                                                                // 313
};                                                                                                           // 314
                                                                                                             //
var errorHeader = function (res, code) {                                                                     // 316
	var header = {                                                                                              // 317
		"Content-Type": "text/html",                                                                               // 318
		Server: settings.server                                                                                    // 319
	};                                                                                                          // 317
	res.writeHead(code, header);                                                                                // 322
};                                                                                                           // 323
                                                                                                             //
handler.on("notFound", function (res, e) {                                                                   // 325
	errorHeader(res, 404);                                                                                      // 326
	res.end("<!DOCTYPE html><html lang=\"en\">" + "<head><title>404 Not found</title>" + "<style>body{font-family:helvetica,sans-serif;color:#ffffff;background-color:#111111;text-align:center;}h1{font-weight:100;}" + "</style></head>" + "<body>" + "<h1>Sorry :(</h1>" + "<p>i can't file that file, please verify that url it's correct</p>" + "</body></html>");
	console.error("404 File not found - " + (e ? e.message : ""));                                              // 335
});                                                                                                          // 336
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx"
  ]
});
require("./lib/storage.js");
require("./server/functions.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
