var require = meteorInstall({"lib":{"storage.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// lib/storage.js                                                                                               //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
Images = new FS.Collection("Images", {                                                                          // 1
    stores: [new FS.Store.GridFS("container")]                                                                  // 2
});                                                                                                             // 1
Codigos = new Mongo.Collection("Codigos");                                                                      // 10
Images.allow({                                                                                                  // 11
    insert: function () {                                                                                       // 12
        function insert() {                                                                                     // 12
            return true;                                                                                        // 13
        }                                                                                                       // 14
                                                                                                                //
        return insert;                                                                                          // 12
    }(),                                                                                                        // 12
    remove: function () {                                                                                       // 15
        function remove() {                                                                                     // 15
            return true;                                                                                        // 16
        }                                                                                                       // 17
                                                                                                                //
        return remove;                                                                                          // 15
    }(),                                                                                                        // 15
    update: function () {                                                                                       // 18
        function update() {                                                                                     // 18
            return true;                                                                                        // 19
        }                                                                                                       // 20
                                                                                                                //
        return update;                                                                                          // 18
    }(),                                                                                                        // 18
    download: function () {                                                                                     // 21
        function download() {                                                                                   // 21
            return true;                                                                                        // 22
        }                                                                                                       // 23
                                                                                                                //
        return download;                                                                                        // 21
    }()                                                                                                         // 21
});                                                                                                             // 11
Codigos.allow({                                                                                                 // 25
    insert: function () {                                                                                       // 26
        function insert() {                                                                                     // 26
            return true;                                                                                        // 27
        }                                                                                                       // 28
                                                                                                                //
        return insert;                                                                                          // 26
    }(),                                                                                                        // 26
    remove: function () {                                                                                       // 29
        function remove() {                                                                                     // 29
            return true;                                                                                        // 30
        }                                                                                                       // 31
                                                                                                                //
        return remove;                                                                                          // 29
    }(),                                                                                                        // 29
    update: function () {                                                                                       // 32
        function update() {                                                                                     // 32
            return true;                                                                                        // 33
        }                                                                                                       // 34
                                                                                                                //
        return update;                                                                                          // 32
    }()                                                                                                         // 32
});                                                                                                             // 25
Images.deny({                                                                                                   // 36
    insert: function () {                                                                                       // 37
        function insert() {                                                                                     // 37
            return false;                                                                                       // 38
        }                                                                                                       // 39
                                                                                                                //
        return insert;                                                                                          // 37
    }(),                                                                                                        // 37
    remove: function () {                                                                                       // 40
        function remove() {                                                                                     // 40
            return false;                                                                                       // 41
        }                                                                                                       // 42
                                                                                                                //
        return remove;                                                                                          // 40
    }(),                                                                                                        // 40
    update: function () {                                                                                       // 43
        function update() {                                                                                     // 43
            return false;                                                                                       // 44
        }                                                                                                       // 45
                                                                                                                //
        return update;                                                                                          // 43
    }(),                                                                                                        // 43
    download: function () {                                                                                     // 46
        function download() {                                                                                   // 46
            return false;                                                                                       // 47
        }                                                                                                       // 48
                                                                                                                //
        return download;                                                                                        // 46
    }()                                                                                                         // 46
});                                                                                                             // 36
Codigos.deny({                                                                                                  // 50
    insert: function () {                                                                                       // 51
        function insert() {                                                                                     // 51
            return false;                                                                                       // 52
        }                                                                                                       // 53
                                                                                                                //
        return insert;                                                                                          // 51
    }(),                                                                                                        // 51
    remove: function () {                                                                                       // 54
        function remove() {                                                                                     // 54
            return false;                                                                                       // 55
        }                                                                                                       // 56
                                                                                                                //
        return remove;                                                                                          // 54
    }(),                                                                                                        // 54
    update: function () {                                                                                       // 57
        function update() {                                                                                     // 57
            return false;                                                                                       // 58
        }                                                                                                       // 59
                                                                                                                //
        return update;                                                                                          // 57
    }()                                                                                                         // 57
});                                                                                                             // 50
if (Meteor.isServer) {                                                                                          // 61
    Meteor.publish("files.all", function () {                                                                   // 62
        return Images.find();                                                                                   // 63
    });                                                                                                         // 64
    Meteor.publish("codigos", function () {                                                                     // 65
        return Codigos.find();                                                                                  // 66
    });                                                                                                         // 67
}                                                                                                               // 68
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"api":{"Ads.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// imports/api/Ads.js                                                                                           //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
Ad = new Mongo.Collection('ads');                                                                               // 1
var schema = {};                                                                                                // 2
schema.Ad = new SimpleSchema({                                                                                  // 3
    timeOut: {                                                                                                  // 4
        type: Number                                                                                            // 5
    }                                                                                                           // 4
});                                                                                                             // 3
Ad.attachSchema(schema.Ad);                                                                                     // 8
                                                                                                                //
if (Meteor.isServer) {                                                                                          // 10
    Meteor.publish("ads", function () {                                                                         // 11
        return Ad.find({});                                                                                     // 12
    });                                                                                                         // 13
}                                                                                                               // 14
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"functions.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// server/functions.js                                                                                          //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
Meteor.startup(function () {                                                                                    // 1
	UploadServer.init({                                                                                            // 2
		tmpDir: process.env.PWD + '/.uploads/tmp',                                                                    // 3
		uploadDir: process.env.PWD + '/.uploads/',                                                                    // 4
		overwrite: true,                                                                                              // 5
		checkCreateDirectories: true,                                                                                 // 6
		cacheTime: 100,                                                                                               // 7
		mimeTypes: {                                                                                                  // 8
			"jpeg": "image/jpeg",                                                                                        // 9
			"jpg": "image/jpeg",                                                                                         // 10
			"png": "image/png",                                                                                          // 11
			"gif": "image/gif",                                                                                          // 12
			"mp4": "video/mp4"                                                                                           // 13
		}                                                                                                             // 8
		// ,finished:function(fileInfo){                                                                              // 15
		// 	function fixedEncodeURIComponent (str) {                                                                  // 16
		// 	  return encodeURIComponent(str).replace(/[!'()*]/g, function(c) {                                        // 17
		// 	    return '%' + c.charCodeAt(0).toString(16);                                                            // 18
		// 	  });                                                                                                     // 19
		// 	}                                                                                                         // 20
		// 	var options = Options.findOne({"_id":"01"});                                                              // 21
		// 	Options.update({"_id": "01"}, {$push: {"ads.pictureUrls": options.general.adminUrl+"/upload/"+fixedEncodeURIComponent(fileInfo.name)}});
		// 	console.log('File uploaded: '+fixedEncodeURIComponent(fileInfo.name));                                    // 23
		// }                                                                                                          // 24
		, getDirectory: function () {                                                                                 // 2
			function getDirectory(fileInfo, formData) {                                                                  // 25
				if (formData && formData.directoryName != null) {                                                           // 26
					return formData.directoryName;                                                                             // 27
				}                                                                                                           // 28
				return "";                                                                                                  // 29
			}                                                                                                            // 30
                                                                                                                //
			return getDirectory;                                                                                         // 25
		}(),                                                                                                          // 25
		finished: function () {                                                                                       // 31
			function finished(fileInfo, formData) {                                                                      // 31
				function fixedEncodeURIComponent(str) {                                                                     // 32
					return encodeURIComponent(str).replace(/[!'()*]/g, function (c) {                                          // 33
						return '%' + c.charCodeAt(0).toString(16);                                                                // 34
					});                                                                                                        // 35
				}                                                                                                           // 36
				console.log(formData.type);                                                                                 // 37
				if (formData.type == 'ad') {                                                                                // 38
					if (fileInfo.type == 'image/jpeg' || fileInfo.type == 'image/png') {                                       // 39
						console.log("uploaded file it's an ad");                                                                  // 40
						var options = Options.findOne({ "_id": "01" });                                                           // 41
						Options.update({ "_id": "01" }, { $push: { "ads.pictureUrls": options.general.adminUrl + "/upload/" + fixedEncodeURIComponent(fileInfo.name) } });
						console.log('Ad uploaded: ' + fixedEncodeURIComponent(fileInfo.name));                                    // 43
					}                                                                                                          // 44
				}                                                                                                           // 45
				if (formData.type == 'videoTop') {                                                                          // 46
					console.log("uploaded file it's a video");                                                                 // 47
					var options = Options.findOne({ "_id": "01" });                                                            // 48
					Options.update({ "_id": "01" }, { $set: { "Videos.top": options.general.adminUrl + "/stream/" + fixedEncodeURIComponent(fileInfo.name) } });
					console.log('Top video uploaded: ' + fixedEncodeURIComponent(fileInfo.name));                              // 50
				}                                                                                                           // 51
				if (formData.type == 'videoBottom') {                                                                       // 52
					console.log("uploaded file it's a video");                                                                 // 53
					var options = Options.findOne({ "_id": "01" });                                                            // 54
					Options.update({ "_id": "01" }, { $set: { "Videos.bottom": options.general.adminUrl + "/stream/" + fixedEncodeURIComponent(fileInfo.name) } });
					console.log('Bottom video uploaded: ' + fixedEncodeURIComponent(fileInfo.name));                           // 56
				}                                                                                                           // 57
			}                                                                                                            // 58
                                                                                                                //
			return finished;                                                                                             // 31
		}()                                                                                                           // 31
	});                                                                                                            // 2
});                                                                                                             // 60
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":["meteor/meteor","../imports/api/Ads",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// server/main.js                                                                                               //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});module.import('../imports/api/Ads');
                                                                                                                // 2
                                                                                                                //
Meteor.startup(function () {                                                                                    // 4
	Meteor.methods({                                                                                               // 5
		uploadFile: function () {                                                                                     // 6
			function uploadFile(fileInfo) {                                                                              // 6
				/*Por seguridad podriamos implementar la subida                                                             // 7
      del archivo en el server, es opcional                                                                     //
    */                                                                                                          //
			}                                                                                                            // 10
                                                                                                                //
			return uploadFile;                                                                                           // 6
		}(),                                                                                                          // 6
		deleteImage: function () {                                                                                    // 11
			function deleteImage(imageRef) {                                                                             // 11
				if (Meteor.userId) {                                                                                        // 12
					Images.remove({ _id: imageRef });                                                                          // 13
					Codigos.remove({ Codigo: imageRef });                                                                      // 14
					return "ok";                                                                                               // 15
				} else {                                                                                                    // 16
					throw new Meteor.Error("No-autorizado");                                                                   // 17
				}                                                                                                           // 18
			}                                                                                                            // 19
                                                                                                                //
			return deleteImage;                                                                                          // 11
		}(),                                                                                                          // 11
		timeoutAd: function () {                                                                                      // 20
			function timeoutAd(timeout, id) {                                                                            // 20
				if (Meteor.userId) {                                                                                        // 21
					Ad.update({ _id: id }, { $set: { timeOut: timeout } });                                                    // 22
					Codigos.update({}, { $set: { Time: timeout } }, { multi: true });                                          // 23
					return "Ok";                                                                                               // 24
				} else {                                                                                                    // 25
					throw new Meteor.Error("No-autorizado");                                                                   // 26
				}                                                                                                           // 27
			}                                                                                                            // 28
                                                                                                                //
			return timeoutAd;                                                                                            // 20
		}(),                                                                                                          // 20
		timeoutbyAd: function () {                                                                                    // 29
			function timeoutbyAd(imageRef, timeout) {                                                                    // 29
				if (Meteor.userId) {                                                                                        // 30
					Codigos.update({ _id: imageRef._id }, { $set: { Time: timeout } });                                        // 31
					return "Ok";                                                                                               // 32
				} else {                                                                                                    // 33
					throw new Meteor.Error("No-autorizado");                                                                   // 34
				}                                                                                                           // 35
			}                                                                                                            // 36
                                                                                                                //
			return timeoutbyAd;                                                                                          // 29
		}()                                                                                                           // 29
	});                                                                                                            // 5
});                                                                                                             // 38
                                                                                                                //
var fs = Npm.require('fs');                                                                                     // 40
var url = Npm.require("url");                                                                                   // 41
var events = Npm.require("events");                                                                             // 42
var handler = new events.EventEmitter();                                                                        // 43
var mimeTypes = {                                                                                               // 44
	".swf": "application/x-shockwave-flash",                                                                       // 45
	".flv": "video/x-flv",                                                                                         // 46
	".f4v": "video/mp4",                                                                                           // 47
	".f4p": "video/mp4",                                                                                           // 48
	".mp4": "video/mp4",                                                                                           // 49
	".asf": "video/x-ms-asf",                                                                                      // 50
	".asr": "video/x-ms-asf",                                                                                      // 51
	".asx": "video/x-ms-asf",                                                                                      // 52
	".avi": "video/x-msvideo",                                                                                     // 53
	".mpa": "video/mpeg",                                                                                          // 54
	".mpe": "video/mpeg",                                                                                          // 55
	".mpeg": "video/mpeg",                                                                                         // 56
	".mpg": "video/mpeg",                                                                                          // 57
	".mpv2": "video/mpeg",                                                                                         // 58
	".mov": "video/quicktime",                                                                                     // 59
	".movie": "video/x-sgi-movie",                                                                                 // 60
	".mp2": "video/mpeg",                                                                                          // 61
	".qt": "video/quicktime",                                                                                      // 62
	".mp3": "audio/mpeg",                                                                                          // 63
	".wav": "audio/x-wav",                                                                                         // 64
	".aif": "audio/x-aiff",                                                                                        // 65
	".aifc": "audio/x-aiff",                                                                                       // 66
	".aiff": "audio/x-aiff",                                                                                       // 67
	".jpe": "image/jpeg",                                                                                          // 68
	".jpeg": "image/jpeg",                                                                                         // 69
	".jpg": "image/jpeg",                                                                                          // 70
	".png": "image/png",                                                                                           // 71
	".svg": "image/svg+xml",                                                                                       // 72
	".tif": "image/tiff",                                                                                          // 73
	".tiff": "image/tiff",                                                                                         // 74
	".gif": "image/gif",                                                                                           // 75
	".txt": "text/plain",                                                                                          // 76
	".xml": "text/xml",                                                                                            // 77
	".css": "text/css",                                                                                            // 78
	".htm": "text/html",                                                                                           // 79
	".html": "text/html",                                                                                          // 80
	".pdf": "application/pdf",                                                                                     // 81
	".doc": "application/msword",                                                                                  // 82
	".vcf": "text/x-vcard",                                                                                        // 83
	".vrml": "x-world/x-vrml",                                                                                     // 84
	".zip": "application/zip",                                                                                     // 85
	".webm": "video/webm",                                                                                         // 86
	".m3u8": "application/x-mpegurl",                                                                              // 87
	".ts": "video/mp2t",                                                                                           // 88
	".ogg": "video/ogg"                                                                                            // 89
};                                                                                                              // 44
var settings = {                                                                                                // 91
	"mode": "development",                                                                                         // 92
	"forceDownload": false,                                                                                        // 93
	"server": "beanStreamer",                                                                                      // 94
	"maxAge": "3600"                                                                                               // 95
};                                                                                                              // 91
var isNumber = function isNumber(n) {                                                                           // 97
	return !isNaN(parseFloat(n)) && isFinite(n);                                                                   // 98
};                                                                                                              // 99
WebApp.connectHandlers.use(function (req, res, next) {                                                          // 100
	var re = /^\/stream\/(.*)$/.exec(req.url);                                                                     // 101
	if (re !== null) {                                                                                             // 102
		// Only handle URLs that start with /uploads_url_prefix/*                                                     // 102
		var filePath = process.env.PWD + '/.uploads/video/' + re[1];                                                  // 103
		var stat;                                                                                                     // 104
		var ext;                                                                                                      // 105
		var info = {};                                                                                                // 106
		var range = typeof req.headers.range === "string" ? req.headers.range : undefined;                            // 107
		var reqUrl = url.parse(req.url, true);                                                                        // 108
		console.log("range: " + req.headers.range);                                                                   // 109
                                                                                                                //
		ext = filePath.match(/.*(\..+?)$/);                                                                           // 111
		info.mime = mimeTypes[ext[1].toLowerCase()];                                                                  // 112
		console.log("extension: " + info.mime);                                                                       // 113
                                                                                                                //
		try {                                                                                                         // 115
			data = fs.readFileSync(filePath);                                                                            // 116
		} catch (e) {                                                                                                 // 117
			if (e.code === 'ENOENT') {                                                                                   // 118
				handler.emit("notFound", res, e);                                                                           // 119
				return false;                                                                                               // 120
			} else {                                                                                                     // 121
				throw e;                                                                                                    // 122
			}                                                                                                            // 123
		}                                                                                                             // 124
                                                                                                                //
		info.path = filePath;                                                                                         // 126
		info.file = info.path.match(/(.*[\/|\\])?(.+?)$/)[2];                                                         // 127
                                                                                                                //
		// var data = fs.readFileSync(filePath);                                                                      // 129
		stat = fs.statSync(info.path);                                                                                // 130
		// console.log(stat);                                                                                         // 131
                                                                                                                //
		info.start = 0;                                                                                               // 133
		info.end = stat.size - 1;                                                                                     // 134
		info.size = stat.size;                                                                                        // 135
		info.modified = stat.mtime;                                                                                   // 136
		info.rangeRequest = false;                                                                                    // 137
                                                                                                                //
		if (range !== undefined && (range = range.match(/bytes=(.+)-(.+)?/)) !== null) {                              // 139
			// Check range contains numbers and they fit in the file.                                                    // 140
			// Make sure info.start & info.end are numbers (not strings) or stream.pipe errors out if start > 0.         // 141
			info.start = isNumber(range[1]) && range[1] >= 0 && range[1] < info.end ? range[1] - 0 : info.start;         // 142
			info.end = isNumber(range[2]) && range[2] > info.start && range[2] <= info.end ? range[2] - 0 : info.end;    // 143
			info.rangeRequest = true;                                                                                    // 144
		} else if (reqUrl.query.start || reqUrl.query.end) {                                                          // 145
			// This is a range request, but doesn't get range headers. So there.                                         // 146
			info.start = isNumber(reqUrl.query.start) && reqUrl.query.start >= 0 && reqUrl.query.start < info.end ? reqUrl.query.start - 0 : info.start;
			info.end = isNumber(reqUrl.query.end) && reqUrl.query.end > info.start && reqUrl.query.end <= info.end ? reqUrl.query.end - 0 : info.end;
		}                                                                                                             // 149
                                                                                                                //
		info.length = info.end - info.start + 1;                                                                      // 151
		console.log("length: " + info.length);                                                                        // 152
		console.log("rangeRequest?: " + info.rangeRequest);                                                           // 153
		console.log("serving file: " + filePath);                                                                     // 154
                                                                                                                //
		downloadHeader(res, info);                                                                                    // 156
                                                                                                                //
		stream = fs.createReadStream(info.path, { flags: "r", start: info.start, end: info.end });                    // 158
		stream.pipe(res);                                                                                             // 159
		return true;                                                                                                  // 160
	} else {                                                                                                       // 162
		next();                                                                                                       // 163
	};                                                                                                             // 164
});                                                                                                             // 165
                                                                                                                //
var downloadHeader = function downloadHeader(res, info) {                                                       // 167
	var code = 200;                                                                                                // 168
	var header;                                                                                                    // 169
                                                                                                                //
	header = {                                                                                                     // 171
		"Cache-Control": "public; max-age=" + settings.maxAge,                                                        // 172
		Connection: "keep-alive",                                                                                     // 173
		"Content-Type": info.mime,                                                                                    // 174
		"Content-Disposition": "inline; filename=" + info.file + ";",                                                 // 175
		"Accept-Ranges": "bytes"                                                                                      // 176
	};                                                                                                             // 171
                                                                                                                //
	if (info.rangeRequest) {                                                                                       // 179
		// Partial http response                                                                                      // 180
		code = 206;                                                                                                   // 181
		header.Status = "206 Partial Content";                                                                        // 182
		header["Content-Range"] = "bytes " + info.start + "-" + info.end + "/" + info.size;                           // 183
	}                                                                                                              // 184
                                                                                                                //
	header.Pragma = "public";                                                                                      // 186
	header["Last-Modified"] = info.modified.toUTCString();                                                         // 187
	header["Content-Transfer-Encoding"] = "binary";                                                                // 188
	header["Content-Length"] = info.length;                                                                        // 189
	if (settings.cors) {                                                                                           // 190
		header["Access-Control-Allow-Origin"] = "*";                                                                  // 191
		header["Access-Control-Allow-Headers"] = "Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept";
	}                                                                                                              // 193
	header.Server = settings.server;                                                                               // 194
	header.Server = settings.server;                                                                               // 195
                                                                                                                //
	res.writeHead(code, header);                                                                                   // 197
};                                                                                                              // 198
                                                                                                                //
var errorHeader = function errorHeader(res, code) {                                                             // 200
	var header = {                                                                                                 // 201
		"Content-Type": "text/html",                                                                                  // 202
		Server: settings.server                                                                                       // 203
	};                                                                                                             // 201
                                                                                                                //
	res.writeHead(code, header);                                                                                   // 206
};                                                                                                              // 207
                                                                                                                //
handler.on("notFound", function (res, e) {                                                                      // 209
	errorHeader(res, 404);                                                                                         // 210
	res.end("<!DOCTYPE html><html lang=\"en\">" + "<head><title>404 Not found</title>" + "<style>body{font-family:helvetica,sans-serif;color:#ffffff;background-color:#111111;text-align:center;}h1{font-weight:100;}" + "</style></head>" + "<body>" + "<h1>Sorry :(</h1>" + "<p>i can't file that file, please verify that url it's correct</p>" + "</body></html>");
	console.error("404 File not found - " + (e ? e.message : ""));                                                 // 219
});                                                                                                             // 220
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./lib/storage.js");
require("./server/functions.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
